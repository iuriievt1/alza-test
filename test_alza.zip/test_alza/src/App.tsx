import { NotebookPage } from './pages/NotebookPage'

export default function App() {
  return <NotebookPage />
}
